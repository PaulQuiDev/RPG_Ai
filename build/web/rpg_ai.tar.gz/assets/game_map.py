
import math

import pygame

from settings import (
    WINDOW_WIDTH,
    WINDOW_HEIGHT,
    INTERACT_COLOR,
    INTERACT_BASE_ALPHA,
    INTERACT_GLOW_COLOR,
    INTERACT_GLOW_ALPHA,
    INTERACT_GLOW_PAD,
    INTERACT_MAX_SCALE,
    INTERACT_PROXIMITY,
    INTERACT_CONTACT,
    INTERACT_BLUE_THRESHOLD,
    INTERACT_MIN_AREA,
    INTERACT_MATCH_TOLERANCE,
    FG_MIN_AREA,
)


# Objets « marchables » : dans la segmentation, un objet qui est à la
# fois « très bleu » (b > seuil) et « très vert » (g > seuil) est un
# objet interactif sur lequel le joueur peut *marcher* (et interagir).
# Seuils calibrés sur le masque du village : centre de lanterne ~(0,
# 112, 255), sol ~(82, 193, 17), mur ~(255, 22, 19) -> aucun
# chevauchement.
WALKABLE_BLUE_THRESHOLD = 100   # « très bleu » : b > 100 (idempotent à INTERACT_BLUE_THRESHOLD)
WALKABLE_GREEN_THRESHOLD = 50   # « très vert » : g > 50  (seuil volontairement bas :
                                # min ~58 sur les lanternes ; l'anti-aliasing des
                                # bords descend jusqu'à ~58. Les murs (b~19) et
                                # le sol (b~17) échouent sur b > WALKABLE_BLUE_THRESHOLD)


class GameMap:
    def __init__(self, background_path, mask_path,
                 foreground_path=None, perspective=None,
                 interactions=None, npcs=None, name=None):
        self.perspective = perspective or {
            "enabled": False,
            "top_scale": 1.0,
            "bottom_scale": 1.0,
        }
        self.interactions = interactions or []
        # Personnage de la carte (NPC) : liste de dicts déclarée dans settings.
        self.npc_data = list(npcs or [])
        self.name = name

        try:
            original = pygame.image.load(
                str(background_path)
            ).convert()

            mask_original = pygame.image.load(
                str(mask_path)
            ).convert()

        except (pygame.error, FileNotFoundError) as error:
            raise RuntimeError(
                f"Impossible de charger la carte : {error}"
            ) from error

        if original.get_size() != mask_original.get_size():
            raise ValueError(
                "Le masque doit avoir la même taille que le fond."
            )

        self.background = pygame.transform.smoothscale(
            original, (WINDOW_WIDTH, WINDOW_HEIGHT)
        )

        self.collision_mask = pygame.transform.scale(
            mask_original, (WINDOW_WIDTH, WINDOW_HEIGHT)
        )

        self.width = WINDOW_WIDTH
        self.height = WINDOW_HEIGHT

        # Couche de premier plan (FG) : optionnelle par carte.
        # Chargée avec sa transparence, alignée sur le fond
        # (même dimensions et positions que vil1.png).
        self._fg_surface = None
        if foreground_path is not None:
            try:
                fg_src = pygame.image.load(
                    str(foreground_path)
                ).convert_alpha()

                if fg_src.get_size() != (WINDOW_WIDTH, WINDOW_HEIGHT):
                    fg_src = pygame.transform.smoothscale(
                        fg_src, (WINDOW_WIDTH, WINDOW_HEIGHT)
                    )

                self._fg_surface = fg_src
            except (pygame.error, FileNotFoundError) as error:
                print(
                    "Couche FG ignorée (fichier introuvable) : "
                    f"{error}"
                )

        # Objets interactifs (pixels bleus du masque) : extraits et
        # pré-rendus au chargement pour ne rien calculer par frame.
        # 1) Sanitise les interactions (position manquante / mal formée /
        #    hors carte) AVANT l'extraction : sans ça, ``_extract_interactables``
        #    lève KeyError/TypeError sur ``inter["pos"]``.
        self._sanitize_interactions()
        self.interact_layer, self.interact_objects = self._extract_interactables()
        self._validate_interactions()

        # Avertissements de configuration : loggés à la création de la carte
        # (et accessibles via ``self.interaction_warnings``) pour que les
        # erreurs de positions dans settings.py soient visibles tout de suite.
        for warn in self.interaction_warnings:
            print(f"[AVERTISSEMENT] {warn}")

        # Éléments de premier plan (composantes de la FG) : extraits et
        # pré-rendus (surface tight, alpha conservé).
        self.fg_elements = self._extract_fg_elements()

        # Personnages de la carte (NPC).
        self.npcs = self._build_npcs()

    def _is_interactive(self, obj):
        """Un objet bleu est « interactif » s'il est associé à un
        comportement (action ou interaction dans self.interactions).
        Sinon, c'est un simple objet décoratif (tinté, non jouable)."""
        return bool(obj.get("action")) or obj.get("interaction")

    def _interaction_label(self, obj):
        """Nom lisible de l'objet : le nom (``name``) s'il existe, sinon
        l'action, sinon vide. Sert à l'affichage « agir (I) sur : X »."""
        name = obj.get("name")
        if name:
            return name
        # Robuste à ``interaction`` == None (objet décoratif) : la clé peut
        # exister avec pour valeur None, le défaut ``{}`` ne s'applique donc
        # que si la clé est ABSENT.
        action = obj.get("action") or ""
        interaction = obj.get("interaction")
        if isinstance(interaction, dict):
            return action or interaction.get("label", "")
        return action

    def count_action(self, action):
        """Nombre d'objets interactifs de la carte ayant ``action``."""
        count = 0
        for obj in self.interact_objects:
            if obj.get("action") == action:
                count += 1
        return count

    def _sanitize_interactions(self):
        """Solution globale (P6) : valide la position de chaque interaction
        (clé « interactions » de settings.py) AVANT le traitement.

        Une interaction est conservée seulement si son ``pos`` :
        - existe (clé ``pos`` présente),
        - est un tableau de 2 éléments,
        - est non-numérique (deux nombres).

        Les invalides sont **retirées** de ``self.interactions`` et un
        avertissement est produit. Les positions hors des bornes de la carte
        sont **conservées** (format valide) mais signalées par un avertissement
        ; elles ne peuvent pas être associées à un objet bleu (celui-ci est
        toujours dans la carte) et recevront l'avertissement « orphelin »
        dans ``_validate_interactions``.

        Retourne la liste des avertissements (écrits aussi dans
        ``self.interaction_warnings``).
        """
        warnings = []
        cleaned = []

        def _is_in_bounds(px, py):
            return 0.0 <= px < self.width and 0.0 <= py < self.height

        for inter in self.interactions:
            if not isinstance(inter, dict):
                warnings.append(
                    f"{self.name} : interaction non-dict ignorée ({inter!r})."
                )
                continue

            pos = inter.get("pos")

            # 1) Position manquante.
            if pos is None:
                warnings.append(
                    f"{self.name} : interaction sans position (clé « pos » "
                    f"manquante) : (action={inter.get('action')!r}, "
                    f"name={inter.get('name')!r}) — impossible de l'associer "
                    f"à un objet bleu ; à corriger dans settings.py."
                )
                continue

            # 2) Format : doit être un tableau de 2 éléments.
            if not isinstance(pos, (list, tuple)) or len(pos) != 2:
                warnings.append(
                    f"{self.name} : interaction pos mal formée ({pos!r}) : "
                    f"doit être un tableau [x, y] de 2 nombres."
                )
                continue

            # 3) Valeurs non-numériques.
            try:
                px, py = float(pos[0]), float(pos[1])
            except (TypeError, ValueError):
                warnings.append(
                    f"{self.name} : interaction pos non numérique ({pos!r}) : "
                    f"doit être un tableau [x, y] de 2 nombres."
                )
                continue
            if math.isnan(px) or math.isnan(py):
                warnings.append(
                    f"{self.name} : interaction pos NaN ({pos!r}) : doit être "
                    f"un tableau [x, y] de 2 nombres."
                )
                continue

            # 4) Hors des bornes de la carte : signalée, mais conservée
            #    (format valide ; orpheline garantie par _validate_interactions).
            if not _is_in_bounds(px, py):
                warnings.append(
                    f"{self.name} : interaction pos hors carte "
                    f"({int(round(px))}, {int(round(py))}) : doit être dans "
                    f"[0, {self.width}] x [0, {self.height}]. Vérifie la "
                    f"position dans settings.py."
                )

            cleaned.append(inter)

        self.interactions = cleaned
        self.interaction_warnings = warnings
        return warnings


    def _validate_interactions(self):
        """Solution globale : associe chaque interaction à un objet bleu
        (tinté) à proximité, et valide la cohérence des deux côtés.

        1) Chaque objet bleu doit avoir une action (sinon, c'est
        « décoratif » => avertissement « sans comportement associé »).
        2) Chaque interaction (dans self.interactions) doit toucher au
        moins un objet bleu (sinon => avertissement « objet hors carte »).

        Les avertissements sont loggés à la création de la carte et
        accessibles via ``self.interaction_warnings``.
        """
        # Appende aux avertissements de ``_sanitize_interactions``
        # (positions manquantes / hors carte) ; si aucun, liste vide.
        warnings = list(getattr(self, "interaction_warnings", []))
        self.interaction_warnings = warnings

        # 1) Associer chaque objet bleu à une interaction (par proximité).
        for obj in self.interact_objects:
            centerx, centery = obj["box"].centerx, obj["box"].centery
            best = None
            best_d = float("inf")
            for inter in self.interactions:
                px, py = inter["pos"]
                d = math.hypot(px - centerx, py - centery)
                if d < best_d:
                    best_d = d
                    best = inter
            if best is not None and best_d <= INTERACT_MATCH_TOLERANCE:
                obj["action"] = best.get("action") or obj.get("action")
                if best.get("name"):
                    obj["name"] = best["name"]
                obj["interaction"] = dict(best)

        # 2) Avertissement : objet bleu SANS comportement associé.
        for obj in self.interact_objects:
            if not self._is_interactive(obj):
                warnings.append(
                    f"{self.name} : objet bleu pos=({int(obj['box'].centerx)}, "
                    f"{int(obj['box'].centery)}) sans comportement associé "
                    f"(action={obj.get('action')!r}) — « agir (I) » restera "
                    f"indisponible ; à lier dans settings.py."
                )

        # 3) Avertissement : interaction sans objet bleu à proximité.
        for inter in self.interactions:
            px, py = inter["pos"]
            associated = False
            for obj in self.interact_objects:
                if self._is_interactive(obj):
                    cx, cy = obj["box"].centerx, obj["box"].centery
                    if math.hypot(px - cx, py - cy) <= INTERACT_MATCH_TOLERANCE:
                        associated = True
                        break
            if not associated:
                label = inter.get("action") or inter.get("name") or inter.get("pos")
                warnings.append(
                    f"{self.name} : interaction pos=({int(px)}, {int(py)}) "
                    f"(action={inter.get('action')!r}) sans objet bleu associé "
                    f"({self.name}) — vérifie la position dans settings.py."
                )
        return warnings

    def draw(self, screen, player=None, collisions=True):
        """Fond + NPC + couche FG derrière le joueur.

        Ordre (arrière -> proche) : fond, NPC derrière le joueur
        (y <= player.y), puis FG derrière (box.bottom <= player.y).
        La couche interaction (teint bleu + halo) est redessée dans
        draw_top, au-dessus de tout, pour garantir que la couleur
        d'interaction reste toujours visible.
        """
        screen.blit(self.background, (0, 0))
        self._draw_npcs(screen, player, front=False)
        self._draw_fg_back(screen, player)

    def draw_top(self, screen, player, time_ms=0, collisions=True):
        """NPC + couche FG devant le joueur + couche interaction.

        Les NPC devant le joueur (y > player.y) et la FG devant
        (box.bottom > player.y) sont ici, devant le joueur ; la couche
        interaction est au-dessus de tout, pour garantir que la couleur
        d'interaction reste toujours visible.
        """
        self._draw_npcs(screen, player, front=True)
        self._draw_fg_front(screen, player, collisions)
        self._draw_interaction_layer(screen, player, time_ms)

    def _draw_fg_back(self, screen, player):
        """Éléments de FG derrière le joueur (box.bottom <= player.y).

        Sans joueur, aucun élément n'est "devant" : on dessine tout."""
        if not self.fg_elements:
            return

        if player is None:
            for el in self.fg_elements:
                screen.blit(el["surf"], (el["x0"], el["y0"]))
            return

        py = player.y
        for el in self.fg_elements:
            if not (el["box"].bottom > py):
                screen.blit(el["surf"], (el["x0"], el["y0"]))

    def _draw_fg_front(self, screen, player, collisions):
        """Éléments de FG devant le joueur (box.bottom > player.y).

        En mode sans collisions, le joueur est toujours devant : on ne
        dessine aucun élément de FG au-dessus de lui.
        """
        if not collisions or player is None or not self.fg_elements:
            return

        py = player.y
        for el in self.fg_elements:
            if el["box"].bottom > py:
                screen.blit(el["surf"], (el["x0"], el["y0"]))

    def get_focused_object(self, player):
        """Retourne l'objet interactif le plus proche du joueur
        (dans la portée), ou None s'il n'y en a pas.

        Fixe le bug « agir (I) sur : None » : on ne considère QUE les
        objets bleus interactifs (associés à un comportement). Un objet
        bleu décoratif (sans action/interaction) n'est jamais retourné.
        """
        if player is None or not self.interact_objects:
            return None
        px, py = player.x, player.y
        best = None
        best_d = INTERACT_PROXIMITY
        for obj in self.interact_objects:
            if not self._is_interactive(obj):
                continue
            d = math.hypot(px - obj["box"].centerx,
                           py - obj["box"].centery)
            if d < best_d:
                best_d = d
                best = obj
        return best

    def _draw_interaction_layer(self, screen, player, time_ms=0):
        """Teint bleu + halos.

        Seul l'objet le plus proche (dans la portée) CLINOTTE
        (halo pulsant). Les autres objets en portée ont un halo
        statique, plus discret. Le teint bleu de base reste
        toujours visible sur tous les objets.
        """
        screen.blit(self.interact_layer, (0, 0))

        if player is None or not self.interact_objects:
            return

        t = time_ms * 0.004
        px, py = player.x, player.y
        objs = self.interact_objects

        # 1) Objet focalisé : le plus proche dans la portée.
        focus_index = -1
        focus_d = INTERACT_PROXIMITY
        for i, obj in enumerate(objs):
            d = math.hypot(px - obj["box"].centerx,
                           py - obj["box"].centery)
            if d < focus_d:
                focus_d = d
                focus_index = i
        if focus_index == -1:
            return

        # 2) Halo PULSANT (clinotage) pour l'objet focalisé uniquement.
        focus = objs[focus_index]
        strength = self._proximity_strength(focus["box"], px, py)
        if strength > 0.0:
            pulse = 0.70 + 0.30 * math.sin(t + focus_index * 0.7)
            alpha = round(255 * strength * pulse)
            if alpha > 0:
                focus["glow"].set_alpha(alpha)
                screen.blit(focus["glow"], focus["glow_pos"])

        # 3) Halos STATIQUES (pas de pulsation) pour les autres objets
        #    présents dans la portée.
        static_factor = 0.45
        for i, obj in enumerate(objs):
            if i == focus_index:
                continue
            d = math.hypot(px - obj["box"].centerx,
                           py - obj["box"].centery)
            if d >= INTERACT_PROXIMITY:
                continue
            strength = self._proximity_strength(obj["box"], px, py)
            alpha = round(255 * strength * static_factor)
            if alpha > 0:
                obj["glow"].set_alpha(alpha)
                screen.blit(obj["glow"], obj["glow_pos"])

    def is_walkable(self, x, y):
        x = int(x)
        y = int(y)

        if not (0 <= x < self.width and 0 <= y < self.height):
            return False

        color = self.collision_mask.get_at((x, y))

        # Vert dominant = zone praticable (sol, herbe, pavés).
        if color.g > color.r and color.g > color.b:
            return True

        # Bleu ET vert = objet interactif sur lequel le joueur peut
        # marcher (ex. : les lanternes du village, segmentées en ~(0,
        # 112, 255)). « Très bleu » reprend le seuil des objets
        # interactifs ; « très vert » filtre les objets bleus non verts.
        return (
            color.b > WALKABLE_BLUE_THRESHOLD
            and color.g > WALKABLE_GREEN_THRESHOLD
        )

    def can_stand_at(self, x: float, y: float, radius: float = 5.0,
                     ignore=None) -> bool:
        """Vérifie que le personnage reste dans une zone praticable.

        Tient compte du masque de collision et des personnages de la
        carte (NPC) : un point est bloqué si le carré de coin touche
        une zone non praticable ou un NPC (rayon + collision_radius),
        sauf pour le NPC `ignore` (utilisé quand on déplace l'un
        d'eux soi-même : construction / patrouille).
        """
        # Collisions avec les personnages de la carte (NPC).
        for npc in self.npcs:
            if npc is ignore or not npc.collide or npc.hidden:
                continue
            if math.hypot(
                x - npc.x,
                y - npc.y,
            ) < radius + npc.collision_radius:
                return False

        # Cornes du carré : zone pratique du masque.
        points = [
            (x - radius, y - radius),
            (x + radius, y - radius),
            (x - radius, y + radius),
            (x + radius, y + radius),
        ]

        return all(
            self.is_walkable(px, py)
            for px, py in points
        )

    def _build_npcs(self):
        """Construit les personnages de la carte (NPC) depuis
        self.npc_data.

        Les positions (et waypoints de patrouille) non praticables
        sont snapées au point praticable le plus proche. Un NPC mal
        configuré est ignoré (message dans la console).
        """
        from npc import Npc

        self.npcs = []
        for index, data in enumerate(self.npc_data):
            try:
                npc = Npc(data, index)
            except Exception as error:  # noqa: BLE001
                print(
                    "NPC ignoré ("
                    f"index {index} / {data.get('name', '?')}): {error}"
                )
                continue

            # Snap de la position initiale vers le point praticable.
            nx, ny = self.find_nearest_walkable(
                npc.x, npc.y, npc.collision_radius
            )
            npc.x, npc.y = float(nx), float(ny)

            # Snap des waypoints de patrouille vers le point praticable.
            for i, (px, py) in enumerate(npc.path):
                if not self.can_stand_at(
                    px, py, npc.collision_radius, ignore=npc
                ):
                    wx, wy = self.find_nearest_walkable(
                        px, py, npc.collision_radius
                    )
                    npc.path[i] = (float(wx), float(wy))

            self.npcs.append(npc)
        return self.npcs

    def find_nearest_walkable(self, x, y, radius):
        """Retourne le point praticable le plus proche de (x, y) pour
        un personnage de `radius`. Cherche en spirale (rangées
        croissantes de distance). Lève RuntimeError si aucun point
        n'est trouvé.
        """
        x, y = float(x), float(y)
        if self.can_stand_at(x, y, radius):
            return int(round(x)), int(round(y))

        max_radius = max(self.width, self.height)
        for dist in range(10, max_radius + 1, 10):
            candidates = []
            for ox in range(-dist, dist + 1, 10):
                candidates.append((int(x) + ox, int(y) - dist))
                candidates.append((int(x) + ox, int(y) + dist))
            for oy in range(-dist + 10, dist, 10):
                candidates.append((int(x) - dist, int(y) + oy))
                candidates.append((int(x) + dist, int(y) + oy))
            for cx, cy in candidates:
                if self.can_stand_at(cx, cy, radius):
                    return cx, cy
        raise RuntimeError(
            f"Aucun point praticable près de ({x:.0f}, {y:.0f})."
        )

    def update_npcs(self, dt, player):
        """Met à jour le comportement de tous les NPC (patrouille).

        Les PNJ en fuite (``hidden``) sont inactifs : « sortis » de la
        carte, donc on ne les met pas à jour.
        """
        for npc in self.npcs:
            if npc.hidden:
                continue
            npc.update(dt, self, player)

    def npcs_in_contact(self, player):
        """Retourne la liste des NPC non-fuiants au contact du joueur.

        Un PNJ en fuite (``hidden``) est « sorti » de la carte : il ne
        compte ni au contact ni à la collision.
        """
        if player is None:
            return []
        return [n for n in self.npcs
                if not n.hidden and n.in_contact(player)]

    def _draw_npcs(self, screen, player, front):
        """Rend les NPC avec le bon découpage devant/derrière le joueur.

        front=False : NPC derrière le joueur (y <= player.y).
        front=True  : NPC devant le joueur (y > player.y).
        Sans joueur, tous les NPC sont considérés en "arrière".
        """
        if not self.npcs:
            return

        if player is None:
            threshold = self.height
        else:
            threshold = player.y

        to_draw = []
        for npc in self.npcs:
            if npc.hidden:
                continue
            if not front:
                if npc.y <= threshold:
                    to_draw.append(npc)
            else:
                if npc.y > threshold:
                    to_draw.append(npc)
        to_draw.sort(key=lambda n: n.y)
        for npc in to_draw:
            npc.draw(screen, self, player)

    def get_perspective_scale(self, y):
        perspective = self.perspective

        if not perspective["enabled"]:
            return 1.0

        top = perspective["top_scale"]
        bottom = perspective["bottom_scale"]

        t = max(0.0, min(1.0, y / self.height))

        return top + (bottom - top) * t

    def _proximity_strength(self, box, px, py):
        """0 loin de l'objet, 1 au contact, lissage linéaire entre."""
        dx = max(box.left - px, px - box.right, 0.0)
        dy = max(box.top - py, py - box.bottom, 0.0)
        d = math.hypot(dx, dy)

        if d <= INTERACT_CONTACT:
            return 1.0
        if d >= INTERACT_PROXIMITY:
            return 0.0
        return (INTERACT_PROXIMITY - d) / (
            INTERACT_PROXIMITY - INTERACT_CONTACT
        )

    def _extract_interactables(self):
        """Extrait les pixels bleus du masque (objets interactifs) à
        l'échelle de la fenêtre et pré-rend leurs couches visuelles.

        Retourne (base_layer, objects) :
        - base_layer : surface SRCALPHA (taille fenêtre) avec le teint
          bleu constant sur tous les objets.
        - objects : liste de dict {
            "box" : Rect de l'objet,
            "glow" : halo pré-rendu (forme agrandie, bords souples),
            "glow_pos" : (x, y) de blit du halo,
        }
        """
        from collections import deque

        mask = self.collision_mask
        w, h = mask.get_size()

        base_layer = pygame.Surface((w, h), pygame.SRCALPHA)
        base_layer.fill((0, 0, 0, 0))

        seen = set()
        objects = []

        for y in range(h):
            for x in range(w):
                if (x, y) in seen or mask.get_at((x, y))[2] <= INTERACT_BLUE_THRESHOLD:
                    continue

                # Parcours en largeur de la zone bleue connectée.
                pixels = []
                q = deque([(x, y)])
                seen.add((x, y))
                x0, x1 = x, x
                y0, y1 = y, y

                while q:
                    cx, cy = q.popleft()
                    pixels.append((cx, cy))
                    if cx < x0:
                        x0 = cx
                    elif cx > x1:
                        x1 = cx
                    if cy < y0:
                        y0 = cy
                    elif cy > y1:
                        y1 = cy

                    for nx, ny in ((cx + 1, cy), (cx - 1, cy),
                                    (cx, cy + 1), (cx, cy - 1)):
                        if 0 <= nx < w and 0 <= ny < h and (nx, ny) not in seen:
                            if mask.get_at((nx, ny))[2] > INTERACT_BLUE_THRESHOLD:
                                seen.add((nx, ny))
                                q.append((nx, ny))

                if len(pixels) < INTERACT_MIN_AREA:
                    continue

                bw = x1 - x0 + 1
                bh = y1 - y0 + 1

                # Teint bleu constant (visibilité de base, toujours visible).
                base = pygame.Surface((bw, bh), pygame.SRCALPHA)
                base.fill((0, 0, 0, 0))
                for px, py in pixels:
                    base.set_at(
                        (px - x0, py - y0),
                        INTERACT_COLOR + (INTERACT_BASE_ALPHA,),
                    )
                base_layer.blit(base, (x0, y0))

                # Forme binaire pour le halo agrandi à bords souples.
                shape = pygame.Surface((bw, bh), pygame.SRCALPHA)
                shape.fill((0, 0, 0, 0))
                for px, py in pixels:
                    shape.set_at((px - x0, py - y0), (255, 255, 255, 255))

                # Halo : forme agrandie de (1 + INTERACT_MAX_SCALE), bords
                # adoucis par smoothscale, sur fond transparent.
                gs = 1.0 + INTERACT_MAX_SCALE
                esw = max(bw, round(bw * gs))
                esh = max(bh, round(bh * gs))
                enlarged = pygame.transform.smoothscale(shape, (esw, esh))

                gw = esw + 2 * INTERACT_GLOW_PAD
                gh = esh + 2 * INTERACT_GLOW_PAD
                glow = pygame.Surface((gw, gh), pygame.SRCALPHA)
                glow.fill((0, 0, 0, 0))
                for yy in range(esh):
                    for xx in range(esw):
                        a = enlarged.get_at((xx, yy))[3]
                        if a > 8:
                            glow.set_at(
                                (xx + INTERACT_GLOW_PAD, yy + INTERACT_GLOW_PAD),
                                (
                                    INTERACT_GLOW_COLOR[0],
                                    INTERACT_GLOW_COLOR[1],
                                    INTERACT_GLOW_COLOR[2],
                                    round(a * INTERACT_GLOW_ALPHA / 255.0),
                                ),
                            )

                cx = x0 + bw / 2.0
                cy = y0 + bh / 2.0
                glow_pos = (round(cx - gw / 2.0), round(cy - gh / 2.0))

                objects.append({
                    "box": pygame.Rect(x0, y0, bw, bh),
                    "glow": glow,
                    "glow_pos": glow_pos,
                    "action": None,
                    "dest": None,
                    "interaction": None,
                })

        # Associer un comportement à chaque objet bleu : le centre de
        # l'objet le plus proche du "pos" de chaque interaction.
        for obj in objects:
            cx, cy = obj["box"].centerx, obj["box"].centery
            best = None
            best_d = INTERACT_MATCH_TOLERANCE
            for inter in self.interactions:
                ipx, ipy = inter["pos"]
                d = math.hypot(cx - ipx, cy - ipy)
                if d < best_d:
                    best_d = d
                    best = inter
            if best is not None:
                obj["action"] = best.get("action")
                obj["dest"] = best.get("dest")
                obj["interaction"] = dict(best)

        return base_layer, objects

    def _extract_fg_elements(self):
        """Extrait les composantes connectées de la couche de premier
        plan et pré-rend chaque élément (surface tight, alpha conservé).

        Retourne une liste de dict :
        {
            "box" : Rect (bbox de l'élément en coords fenêtre),
            "surf" : surface SRCALPHA tight (pixels opaques, bords conservés),
            "x0" : coordonnée x de blit,
            "y0" : coordonnée y de blit,
        }
        """
        if self._fg_surface is None:
            return []

        fg = self._fg_surface
        w, h = fg.get_size()

        # Grille d'alpha pour un accès rapide pendant le BFS.
        alpha_grid = []
        for y in range(h):
            row = []
            for x in range(w):
                row.append(fg.get_at((x, y))[3])
            alpha_grid.append(row)

        from collections import deque

        seen = set()
        elements = []

        for y in range(h):
            for x in range(w):
                if (x, y) in seen or alpha_grid[y][x] <= 12:
                    continue

                # Parcours en largeur de la composante connectée.
                pixels = []
                q = deque([(x, y)])
                seen.add((x, y))
                x0, x1 = x, x
                y0, y1 = y, y

                while q:
                    cx, cy = q.popleft()
                    pixels.append((cx, cy))
                    if cx < x0:
                        x0 = cx
                    elif cx > x1:
                        x1 = cx
                    if cy < y0:
                        y0 = cy
                    elif cy > y1:
                        y1 = cy

                    for nx, ny in ((cx + 1, cy), (cx - 1, cy),
                                    (cx, cy + 1), (cx, cy - 1)):
                        if (
                            0 <= nx < w
                            and 0 <= ny < h
                            and (nx, ny) not in seen
                            and alpha_grid[ny][nx] > 12
                        ):
                            seen.add((nx, ny))
                            q.append((nx, ny))

                if len(pixels) < FG_MIN_AREA:
                    continue

                bw = x1 - x0 + 1
                bh = y1 - y0 + 1

                # Surface tight avec les couleurs/alpha d'origine.
                surf = pygame.Surface((bw, bh), pygame.SRCALPHA)
                surf.fill((0, 0, 0, 0))
                for px, py in pixels:
                    surf.set_at((px - x0, py - y0), fg.get_at((px, py)))

                elements.append({
                    "box": pygame.Rect(x0, y0, bw, bh),
                    "surf": surf,
                    "x0": x0,
                    "y0": y0,
                })

        return elements
